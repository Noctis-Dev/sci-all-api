package com.sci_all.demo.web.dto.request;

public record JwtRequest(
        String refreshToken
) { }
